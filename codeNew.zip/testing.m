i_u1=2;
i_u2=110;
u_play = [U(i_u1);U(i_u2)];
gk_computation;
gL_computation;
figure
hold on
plot(gk1,gL1,'.')
plot(gk2,gL2,'.')
grid